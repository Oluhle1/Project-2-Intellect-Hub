package ell.one.tutorlink.activities;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import ell.one.tutorlink.R;

public class Reminder extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reminder);
    }
}